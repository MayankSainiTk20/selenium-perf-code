package com.intuit.ui.perf.beans;

public class WorkflowVO {

	private String ref_id;
	private String env;

	public String getRef_id() {
		return ref_id;
	}

	public void setRef_id(String ref_id) {
		this.ref_id = ref_id;
	}

	public String getEnv() {
		return env;
	}

	public void setEnv(String env) {
		this.env = env;
	}
}
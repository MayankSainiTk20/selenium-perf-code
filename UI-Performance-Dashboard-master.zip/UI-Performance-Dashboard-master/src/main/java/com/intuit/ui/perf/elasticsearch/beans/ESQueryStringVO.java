package com.intuit.ui.perf.elasticsearch.beans;

public class ESQueryStringVO {

	private ESQueryVO query_string;

	public ESQueryVO getQuery_string() {
		return query_string;
	}

	public void setQuery_string(ESQueryVO query_string) {
		this.query_string = query_string;
	}

}

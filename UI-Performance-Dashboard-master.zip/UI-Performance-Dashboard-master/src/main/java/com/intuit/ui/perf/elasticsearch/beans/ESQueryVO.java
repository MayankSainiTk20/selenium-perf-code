package com.intuit.ui.perf.elasticsearch.beans;

public class ESQueryVO {

	private String default_field;
	private String query;
	
	
	public String getDefault_field() {
		return default_field;
	}

	public void setDefault_field(String default_field) {
		this.default_field = default_field;
	}

	public String getQuery() {
		return query;
	}

	public void setQuery(String query) {
		this.query = query;
	}
}

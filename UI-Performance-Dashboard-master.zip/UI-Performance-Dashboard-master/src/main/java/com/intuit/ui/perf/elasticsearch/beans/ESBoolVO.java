package com.intuit.ui.perf.elasticsearch.beans;

public class ESBoolVO {
	
	private ESMustVO bool;

	public ESMustVO getBool() {
		return bool;
	}

	public void setBool(ESMustVO bool) {
		this.bool = bool;
	}

}

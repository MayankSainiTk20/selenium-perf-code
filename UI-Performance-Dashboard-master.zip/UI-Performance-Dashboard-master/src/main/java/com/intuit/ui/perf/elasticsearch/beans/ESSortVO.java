package com.intuit.ui.perf.elasticsearch.beans;

public class ESSortVO {

	private ESRunTimeStampVO runtimestamp;
	
	public ESRunTimeStampVO getRuntimestamp() {
		return runtimestamp;
	}

	public void setRuntimestamp(ESRunTimeStampVO runtimestamp) {
		this.runtimestamp = runtimestamp;
	}
}

package com.intuit.ui.perf.entities;

import org.springframework.data.jpa.repository.JpaRepository;

public interface PerformanceProjectRepository extends JpaRepository<Entity_Project, String>{

}

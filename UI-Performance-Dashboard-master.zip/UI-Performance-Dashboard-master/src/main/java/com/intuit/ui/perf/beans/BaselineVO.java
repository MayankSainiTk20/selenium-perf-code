package com.intuit.ui.perf.beans;

public class BaselineVO {

	private String run_id;
	private String env;
	public String getRun_id() {
		return run_id;
	}

	public void setRun_id(String run_id) {
		this.run_id = run_id;
	}

	


	public String getEnv() {
		return env;
	}

	public void setEnv(String env) {
		this.env = env;
	}
}
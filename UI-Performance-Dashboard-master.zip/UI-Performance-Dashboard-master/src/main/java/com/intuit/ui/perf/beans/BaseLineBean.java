package com.intuit.ui.perf.beans;

public class BaseLineBean {
private String env;
private String run_id;

public String getEnv() {
	return env;
}
public void setEnv(String env) {
	this.env = env;
}
public String getRun_id() {
	return run_id;
}
public void setRun_id(String run_id) {
	this.run_id = run_id;
}

}

package com.intuit.ui.perf.elasticsearch.beans;

public class ESRunTimeStampVO {
	
	private String order;

	public String getOrder() {
		return order;
	}

	public void setOrder(String order) {
		this.order = order;
	}
}
